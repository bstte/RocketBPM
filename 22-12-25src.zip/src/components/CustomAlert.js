import Swal from "sweetalert2";

const CustomAlert = {
  success: (title, text) => {
    Swal.fire({
      icon: "success",
      title: title || "Success",
      text: text || "Operation completed successfully!",
    });
  },

  error: (title, text) => {
    Swal.fire({
      icon: "error",
      title: title || "Error",
      text: text || "Something went wrong!",
    });
  },

  warning: (title, text) => {
    Swal.fire({
      icon: "warning",
      title: title || "Warning",
      text: text || "Be careful with this action!",
    });
  },

  info: (title, text) => {
    Swal.fire({
      icon: "info",
      title: title || "Information",
      text: text || "Here is some important information!",
    });
  },

  confirm: (title, text, confirmCallback, cancelCallback) => {
    Swal.fire({
      icon: "warning",
      title: title || "Are you sure?",
      text: text || "You won’t be able to revert this!",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, confirm!",
    }).then((result) => {
      if (result.isConfirmed && confirmCallback) {
        confirmCallback();
      } else if (
        result.dismiss === Swal.DismissReason.cancel &&
        cancelCallback
      ) {
        cancelCallback();
      }
    });
  },

  confirmExit: (saveCallback, exitWithoutSaveCallback, cancelCallback) => {
    Swal.fire({
      icon: "warning",
      title: "You have unsaved changes",
      text: "Do you want to save before exiting?",
      showDenyButton: true,
      showCancelButton: true,
      confirmButtonText: "Exit (Save & Exit)",
      denyButtonText: "Exit without saving",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#3085d6",
      denyButtonColor: "#f39c12",
      cancelButtonColor: "#aaa",
    }).then((result) => {
      if (result.isConfirmed && saveCallback) {
        saveCallback(); // Save & Exit
      } else if (result.isDenied && exitWithoutSaveCallback) {
        exitWithoutSaveCallback(); // Exit without saving
      } else if (result.isDismissed && cancelCallback) {
        if (cancelCallback) cancelCallback(); // Just stay on the page
      }
    });
  },


  confirmLanguageSwitch: (saveCallback, dontSaveCallback) => {
  Swal.fire({
    icon: "question",
    title: "Save changes before switching language?",
    showCancelButton: true,
    confirmButtonText: "Yes, save & switch",
    cancelButtonText: "No, discard changes",
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
  }).then((result) => {
    if (result.isConfirmed && saveCallback) {
      saveCallback(); // User chose to save first
    } else if (result.dismiss === Swal.DismissReason.cancel && dontSaveCallback) {
      dontSaveCallback(); // User chose not to save
    }
  });
},

};

export default CustomAlert;
